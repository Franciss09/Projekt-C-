#ifndef PROJEKT6_H
#define PROJEKT6_H

typedef struct {
    char imie[30];
    char plec;
    int wiek;
    float wzrost;
    float waga;
    int tryb;
    int ile_schudnac;
    int czas;
    int ilosc_dni;
} Uzytkownik;

typedef struct {
    char nazwa[100];
    int kcal;
    int bialko;
    int tluszcze;
    int weglowodany;
    int typ; 
} Posilek;

extern Posilek posilki[32];

Uzytkownik gromadzenie_danych();
float PPM(Uzytkownik u);
float PAL(Uzytkownik u);
float TDEE(Uzytkownik u);
int deficyt(Uzytkownik u);
int zapotrzebowanie_kaloryczne(Uzytkownik u);
Posilek losuj_posilek(int typ);
void generuj_jadlospis(int kcal_docelowe);
void jadlospis_na_dany_okres(int ilosc,int kalorie);

#endif // PROJEKT6