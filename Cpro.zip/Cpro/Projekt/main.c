#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "projekt6.h"
#include <locale.h>
int main()
{
    setlocale(LC_ALL, "");
    srand(time(NULL));
    int wybor;
    Uzytkownik u;
    int kalorie;

    do {
        printf("\n==== MENU GLOWNE ====\n");
        printf("1. Rozpocznij nowa kalkulacje\n");
        printf("2. Wyjdz z programu\n");
        printf("Wybierz opcje: ");
        scanf_s("%d", &wybor);

        int c;
        while ((c = getchar()) != '\n' && c != EOF);
        

        switch (wybor) {
        case 1:
            u = gromadzenie_danych();
            kalorie = zapotrzebowanie_kaloryczne(u);
            printf("\n%s, twoje dzienne zapotrzebowanie kaloryczne na redukcji to: %d kcal\n", u.imie, kalorie);
            jadlospis_na_dany_okres(u.ilosc_dni, kalorie);
            break;
        case 2:
            printf("Zamykanie programu. Do zobaczenia!\n");
            break;
        default:
            printf("Niepoprawny wybor! Wpisz 1 lub 2.\n");
        }
    } while (wybor != 2);

    return 0;
}