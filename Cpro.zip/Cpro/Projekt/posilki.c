#include "projekt6.h"

Posilek posilki[32] = {
    {"Owsianka z bananem i orzechami", 400, 12, 14, 56, 1},
    {"Jajecznica z chlebem i pomidorem", 450, 20, 28, 28, 1},
    {"Tosty z twaro�kiem", 350, 18, 10, 42, 1},
    {"Pancakes z mas�em orzechowym i syropem klonowym", 800, 18, 30, 85, 1},
    {"Jajka sadzone z boczkiem i pieczywem", 750, 28, 45, 25, 1},
    {"Tosty z awokado, serem i jajkiem sadzonym", 700, 22, 35, 45, 1},
    {"Omlet z serem i boczkiem", 1400, 60, 90, 75, 1},
    {"Kanapka z awokado, jajkiem i majonezem", 1300, 55, 80, 70, 1},

    {"Kurczak z ry�em i broku�ami", 600, 45, 15, 60, 2},
    {"Makaron z tu�czykiem", 550, 38, 14, 65, 2},
    {"Zupa z soczewicy", 500, 22, 12, 55, 2},
    {"Burger wo�owy z serem i frytkami", 950, 40, 50, 60, 2},
    {"Schabowy z ziemniakami i mizeri�", 880, 38, 40, 55, 2},
    {"Kebab z ry�em i warzywami", 1000, 45, 35, 70, 2},
    {"Stek z ziemniakami i mas�em czosnkowym", 1500, 90, 85, 120, 2},
    {"Lasagne z mi�sem i serem", 1350, 75, 80, 110, 2},

    {"Sa�atka z fet� i kurczakiem", 400, 25, 25, 20, 3},
    {"Omlet z warzywami", 450, 28, 26, 18, 3},
    {"Kanapki z jajkiem i awokado", 420, 20, 22, 35, 3},
    {"Tortilla z kurczakiem, serem i warzywami", 800, 35, 30, 60, 3},
    {"Makaron z pesto i parmezanem", 650, 20, 30, 65, 3},
    {"Pizza domowa na grubym cie�cie", 850, 28, 40, 70, 3},
    {"Pizza z pepperoni i podw�jnym serem", 1400, 60, 70, 110, 3},
    {"Makaron carbonara", 1300, 55, 65, 120, 3},

    {"Jogurt z owocami", 300, 12, 8, 38, 4},
    {"Orzechy i jab�ko", 350, 8, 20, 30, 4},
    {"Baton proteinowy", 250, 20, 8, 20, 4},
    {"Smoothie bananowo-orzechowe na mleku", 500, 18, 22, 50, 4},
    {"Gar�� orzech�w mieszanych i ciemna czekolada", 600, 12, 50, 20, 4},
    {"Kanapka z mas�em orzechowym i d�emem", 700, 15, 30, 55, 4},
    {"Shake proteinowy z mas�em orzechowym", 1300, 60, 40, 65, 4},
    {"Energetyczny baton z orzechami i czekolad�", 1350, 55, 45, 70, 4},
};