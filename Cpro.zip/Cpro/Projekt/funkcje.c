#include "projekt6.h"
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <stdlib.h>
#include <string.h> // Potrzebne dla funkcji strcspn


Posilek posilki[32] = {
    {"Owsianka z bananem i orzechami", 400, 12, 14, 56, 1},
    {"Jajecznica z chlebem i pomidorem", 450, 20, 28, 28, 1},
    {"Tosty z twaro�kiem", 350, 18, 10, 42, 1},
    {"Pancakes z mas�em orzechowym i syropem klonowym", 800, 18, 30, 85, 1},
    {"Jajka sadzone z boczkiem i pieczywem", 750, 28, 45, 25, 1},
    {"Tosty z awokado, serem i jajkiem sadzonym", 700, 22, 35, 45, 1},
    {"Omlet z serem i boczkiem", 1400, 60, 90, 75, 1},
    {"Kanapka z awokado, jajkiem i majonezem", 1300, 55, 80, 70, 1},
    {"Kurczak z ry�em i broku�ami", 600, 45, 15, 60, 2},
    {"Makaron z tu�czykiem", 550, 38, 14, 65, 2},
    {"Zupa z soczewicy", 500, 22, 12, 55, 2},
    {"Burger wo�owy z serem i frytkami", 950, 40, 50, 60, 2},
    {"Schabowy z ziemniakami i mizeri�", 880, 38, 40, 55, 2},
    {"Kebab z ry�em i warzywami", 1000, 45, 35, 70, 2},
    {"Stek z ziemniakami i mas�em czosnkowym", 1500, 90, 85, 120, 2},
    {"Lasagne z mi�sem i serem", 1350, 75, 80, 110, 2},
    {"Sa�atka z fet� i kurczakiem", 400, 25, 25, 20, 3},
    {"Omlet z warzywami", 450, 28, 26, 18, 3},
    {"Kanapki z jajkiem i awokado", 420, 20, 22, 35, 3},
    {"Tortilla z kurczakiem, serem i warzywami", 800, 35, 30, 60, 3},
    {"Makaron z pesto i parmezanem", 650, 20, 30, 65, 3},
    {"Pizza domowa na grubym cie�cie", 850, 28, 40, 70, 3},
    {"Pizza z pepperoni i podw�jnym serem", 1400, 60, 70, 110, 3},
    {"Makaron carbonara", 1300, 55, 65, 120, 3},
    {"Jogurt z owocami", 300, 12, 8, 38, 4},
    {"Orzechy i jab�ko", 350, 8, 20, 30, 4},
    {"Baton proteinowy", 250, 20, 8, 20, 4},
    {"Smoothie bananowo-orzechowe na mleku", 500, 18, 22, 50, 4},
    {"Gar�� orzech�w mieszanych i ciemna czekolada", 600, 12, 50, 20, 4},
    {"Kanapka z mas�em orzechowym i d�emem", 700, 15, 30, 55, 4},
    {"Shake proteinowy z mas�em orzechowym", 1300, 60, 40, 65, 4},
    {"Energetyczny baton z orzechami i czekolad�", 1350, 55, 45, 70, 4},
};



Uzytkownik gromadzenie_danych()
{
    Uzytkownik u;
    char bufor[100]; 

    printf("Witaj w symulatorze diet! Zaraz zostaniesz poproszony o podanie podstawowych informacji\n");

    printf("Podaj swoje imie: ");

    fgets(u.imie, sizeof(u.imie), stdin);

    u.imie[strcspn(u.imie, "\n")] = 0;

    do {
        printf("Podaj swoja plec (M/K): ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, " %c", &u.plec, 1); 
        u.plec = toupper(u.plec);
        if (u.plec != 'M' && u.plec != 'K') {
            printf("Niepoprawna wartosc! Wpisz 'M' lub 'K'.\n");
        }
    } while (u.plec != 'M' && u.plec != 'K');

    do {
        printf("Podaj swoj wiek: ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%d", &u.wiek);
        if (u.wiek <= 0) {
            printf("Wiek musi byc liczba dodatnia!\n");
        }
    } while (u.wiek <= 0);

    do {
        printf("Podaj swoj wzrost (cm): ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%f", &u.wzrost);
        if (u.wzrost <= 0) {
            printf("Wzrost musi byc liczba dodatnia!\n");
        }
    } while (u.wzrost <= 0);

    do {
        printf("Podaj swoja wage (kg): ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%f", &u.waga);
        if (u.waga <= 0) {
            printf("Waga musi byc liczba dodatnia!\n");
        }
    } while (u.waga <= 0);

    do {
        printf("Wybierz tryb zycia ktory najbardziej oddaje twoj:\n");
        printf("1. Siedzacy (brak ruchu, praca biurowa)\n");
        printf("2. Niska aktywnosc (np. spacery)\n");
        printf("3. Srednia aktywnosc (np. 2-3 treningi tygodniowo)\n");
        printf("4. Wysoka aktywnosc (sport zawodowy lub codzienne intensywne treningi)\n");
        printf("Wybierz tryb: ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%d", &u.tryb);
        if (u.tryb < 1 || u.tryb > 4) {
            printf("Niepoprawna wartosc! Wpisz liczbe od 1 do 4.\n");
        }
    } while (u.tryb < 1 || u.tryb > 4);

    do {
        printf("Ile chcesz schudnac? (KG): ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%d", &u.ile_schudnac);
        if (u.ile_schudnac < 0) {
            printf("Wartosc musi byc nieujemna!\n");
        }
    } while (u.ile_schudnac < 0);

    do {
        printf("W jakim czasie? (msc): ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%d", &u.czas);
        if (u.czas <= 0) {
            printf("Wartosc musi byc dodatnia!\n");
        }
    } while (u.czas <= 0);

    do {
        printf("Na ile dni chcesz jadlospis? ");
        fgets(bufor, sizeof(bufor), stdin);
        sscanf_s(bufor, "%d", &u.ilosc_dni);
        if (u.ilosc_dni <= 0) {
            printf("Wartosc musi byc dodatnia!\n");
        }
    } while (u.ilosc_dni <= 0);

    return u;
}


float PPM(Uzytkownik u) {
    if (u.plec == 'K') {
        return (10 * u.waga) + (6.25 * u.wzrost) - (5 * u.wiek) - 161;
    }
    else {
        return (10 * u.waga) + (6.25 * u.wzrost) - (5 * u.wiek) + 5;
    }
}

float PAL(Uzytkownik u) {
    switch (u.tryb) {
    case 1: return 1.2f;
    case 2: return 1.4f;
    case 3: return 1.65f;
    case 4: return 2.05f;
    default: return 1.2f;
    }
}

float TDEE(Uzytkownik u) {
    return PPM(u) * PAL(u);
}

int deficyt(Uzytkownik u) {
    if (u.czas <= 0) return 0; 
    int dni = u.czas * 30;
    return (u.ile_schudnac * 7700) / dni;
}

int zapotrzebowanie_kaloryczne(Uzytkownik u) {
    return (int)(TDEE(u) - deficyt(u));
}

void jadlospis_na_dany_okres(int ilosc, int kalorie) {
    for (int i = 1; i <= ilosc; i++) {
        printf("\nJadlospis na dzien %d: \n", i);
        generuj_jadlospis(kalorie);
        printf("\n");
    }
}

Posilek losuj_posilek(int typ) {
    int indeks_startowy = (typ - 1) * 8;
    int losowy_indeks = indeks_startowy + (rand() % 8);
    return posilki[losowy_indeks];
}

#define MAX_POSILKOW 15

void generuj_jadlospis(int kcal_docelowe) {
    Posilek dzien[MAX_POSILKOW];
    int suma_kcal = 0;
    int indeks = 0, proba = 0;

    while (suma_kcal < kcal_docelowe - 100 && indeks < MAX_POSILKOW && proba < 1000) {
        Posilek p = losuj_posilek(rand() % 4 + 1);
        if (suma_kcal + p.kcal <= kcal_docelowe + 100) {
            dzien[indeks++] = p;
            suma_kcal += p.kcal;
        }
        proba++;
    }

    int bialko = 0, tluszcze = 0, weglowodany = 0;
    printf("----------------------------------------\n");
    for (int i = 0; i < indeks; i++) {
        printf("- %s (%d kcal)\n", dzien[i].nazwa, dzien[i].kcal);
        bialko += dzien[i].bialko;
        tluszcze += dzien[i].tluszcze;
        weglowodany += dzien[i].weglowodany;
    }
    printf("----------------------------------------\n");
    printf("Lacznie: %d / %d kcal\n", suma_kcal, kcal_docelowe);
    printf("Bialko: %dg, Tluszcze: %dg, Weglowodany: %dg\n", bialko, tluszcze, weglowodany);
}